// בוחרים או אחד- ארי פוטר  או 2- כלבים או 3- דגלים או 4 שזה מגריל רנדומלית ספרה בין 1ל3 ולפי זה יהיו התמונות
//כשבוחרים 4 גם מה שיבחר מבין ה3 יהיה בחירה רנדומלית- וגם הקלפים שיוצגו מהאיי פי אי יהיו נבחרים רנדומלית
$(document).ready(function () {
    var choose = null;
    while (choose == null) {
        //alert("choose")
        choose = prompt("Please enter your choose: 1- Harry Potter, 2- Dogs, 3- Countries flags, 4-random");
        if (choose != 1 && choose != 2 && choose != 3 && choose != 4)
            choose = null;
    }

    var selection = choose;
    var isRand;
    function shuffle(array) {//הבונוס
        let currentIndex = array.length, temporaryValue, randomIndex;

        while (currentIndex !== 0) {
            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;

            temporaryValue = array[currentIndex];
            array[currentIndex] = array[randomIndex];
            array[randomIndex] = temporaryValue;
        }

        return array;
    }

    // פונקציה לבדיקת טעינת התמונה
    function isImageValid(url) {
        return new Promise((resolve) => {
            const img = new Image();
            img.src = url;
            img.onload = () => resolve(true);
            img.onerror = () => resolve(false);
        });
    }

    // פונקציה להסרת תמונות לא טובות מהמערך
    async function removeInvalidImages(characters) {
        const validCharacters = [];
        for (const character of characters) {
            const isValid = await isImageValid(character.image);
            if (isValid) {
                validCharacters.push(character);
            }
        }
        return validCharacters;
    }

    if (choose == 4) {
        selection = Math.floor(Math.random() * 3) + 1;
        isRand = true;
    }
    console.log(selection);
    if (selection == 1) {
        // קריאה ל-API ויצירת הקלפים בהתאם לנתונים שמוחזרים
        $.getJSON("https://hp-api.herokuapp.com/api/characters/house/gryffindor")
            .done(async function (data) {
                const backImage = data[6].image;

                var characters = data.slice(0, 6);
                if (isRand) {
                    const validCharacters = await removeInvalidImages(shuffle(data));
                    characters = validCharacters.slice(0, 6);
                }

                characters.forEach(character => {
                    // console.log(character.image);
                    let card = `
                    <div class="memory-card" data-framework="${character.name}">
                        <img class="front-face" src="${character.image}" alt="${character.name}" />
                        <img class="back-face" src="${backImage}" alt="JS Badge" />
                    </div>
                `;
                    $('.memory-game').append(card); // הוספת הקלף לקונטיינר של המשחק
                    $('.memory-game').append(card); // הוספת הקלף לקונטיינר של המשחק פעם שניה
                });

                // AddCardEventListener(); // הוספת מאזיני לחיצה לקלפים
                //מחכים שניה עד הפיכה חזרה
                //מיקומים רנדומלים לתמונות
                //שינוי סדר לתמונות
                //אם ניתן לאלמנט קלאס פליפ-יהיה סיבוב

                const cards = document.querySelectorAll(".memory-card");
                //console.log(cards);
                shuffleCards();
                AddCardEventListener();

                function AddCardEventListener() {
                    cards.forEach((card) => {
                        card.addEventListener("click", flipCard);
                    });
                }


                //ערבוב
                function shuffleCards() {
                    cards.forEach((card) => {
                        let randomePosition = Math.floor(Math.random() * 12);
                        //שינוי המיקום באמצעות פרופרטי אורדר של פלקסבוקס
                        card.style.order = randomePosition;
                    });

                    // cards.forEach((card)=>{
                    //      card.classList.add("flip");
                    // });
                }

            });

    }
    else if (selection == 2) {

// פונקציה להסרת תמונות לא טובות מהמערך
async function removeInvalidImages2(images) {
    const validImages = [];
    for (const imageUrl of images) {
        const isValid = await isImageValid(imageUrl);
        if (isValid) {
            validImages.push(imageUrl);
        }
    }
    return validImages;
}


        // קריאה ל-API ויצירת הקלפים בהתאם לנתונים שמוחזרים
        $.getJSON("https://dog.ceo/api/breed/hound/images")
            .done(async function (data) {
                const backImage2 = data.message[6];

                var dogs = data.message.slice(0, 6);
              //  console.log("sss",dogs);
                if (isRand) {
                    // console.log("mess",data.message);
                    const validDogs = await removeInvalidImages2(shuffle(data.message));
                    // console.log("vali",validDogs);
                    dogs = validDogs.slice(0, 6);
                }
                console.log(dogs);

               dogs.forEach(imageUrl => {
                    // console.log(imageUrl);
                    let card = `
         <div class="memory-card" data-framework="${imageUrl}">
         <img class="front-face" src="${imageUrl}" alt="Dog" />
         <img class="back-face" src="${backImage2}" alt="JS Badge" />
     </div>
         `;
                    $('.memory-game').append(card); // הוספת הקלף לקונטיינר של המשחק
                    $('.memory-game').append(card); // הוספת הקלף לקונטיינר של המשחק פעם שניה
                });

                // AddCardEventListener(); // הוספת מאזיני לחיצה לקלפים
                //מחכים שניה עד הפיכה חזרה
                //מיקומים רנדומלים לתמונות
                //שינוי סדר לתמונות
                //אם ניתן לאלמנט קלאס פליפ-יהיה סיבוב

                const cards = document.querySelectorAll(".memory-card");
                //console.log(cards);
                shuffleCards();
                AddCardEventListener();

                function AddCardEventListener() {
                    cards.forEach((card) => {
                        card.addEventListener("click", flipCard);
                    });
                }


                //ערבוב
                function shuffleCards() {
                    cards.forEach((card) => {
                        let randomePosition = Math.floor(Math.random() * 12);
                        //שינוי המיקום באמצעות פרופרטי אורדר של פלקסבוקס
                        card.style.order = randomePosition;
                    });

                    // cards.forEach((card)=>{
                    //      card.classList.add("flip");
                    // });
                }

            });
    }
    else if (selection == 3) {

        async function removeInvalidImages3(flags) {
            // console.log("f",flags);
            const validFlags = [];
            for (const flag of flags) {
                const isValid = await isImageValid(flag.flag);
                if (isValid) {
                    validFlags.push(flag);
                }
            }
            return validFlags;
        }

        // קריאה ל-API ויצירת הקלפים בהתאם לנתונים שמוחזרים
        $.getJSON("https://gist.githubusercontent.com/pratikbutani/20ded7151103bb30737e2ab1b336eb02/raw/be1391e25487ded4179b5f1c8eedb81b01226216/country-flag.json")
            .done(async function (data) {
                const backImage3 = data[6].flag;

              var flags=data.slice(0, 6);
              if (isRand) {
                //   console.log("d ",shuffle(data));
                const validFlags = await removeInvalidImages3(shuffle(data));
                // console.log("val f ",validFlags);
                flags = validFlags.slice(0, 6);
            }

            flags.forEach(country => {
                    //  console.log(country);
                    let card = `
         <div class="memory-card" data-framework="${country.flag}">
         <img class="front-face" src="${country.flag}" alt="${country.name} Flag" />
         <img class="back-face" src="${backImage3}" alt="JS Badge" />
     </div>
         `;
                    $('.memory-game').append(card); // הוספת הקלף לקונטיינר של המשחק
                    $('.memory-game').append(card); // הוספת הקלף לקונטיינר של המשחק פעם שניה
                });

                // AddCardEventListener(); // הוספת מאזיני לחיצה לקלפים
                //מחכים שניה עד הפיכה חזרה
                //מיקומים רנדומלים לתמונות
                //שינוי סדר לתמונות
                //אם ניתן לאלמנט קלאס פליפ-יהיה סיבוב

                const cards = document.querySelectorAll(".memory-card");
                //console.log(cards);
                shuffleCards();
                AddCardEventListener();

                function AddCardEventListener() {
                    cards.forEach((card) => {
                        card.addEventListener("click", flipCard);
                    });
                }


                //ערבוב
                function shuffleCards() {
                    cards.forEach((card) => {
                        let randomePosition = Math.floor(Math.random() * 12);
                        //שינוי המיקום באמצעות פרופרטי אורדר של פלקסבוקס
                        card.style.order = randomePosition;
                    });

                    // cards.forEach((card)=>{
                    //      card.classList.add("flip");
                    // });
                }

            });

    }
    //else alert("no such opt")

    //1 לא בחרתי קלף
    //2 בחרתי אחד
    //3 בחרתי שני קלפים
    let hasFlippedCard = false;//מסמן שלא נבחר אף קלף
    var firstCard;
    var secondCard;
    var lockBoard = false;//כשהוא אמת כולם בדיסייבל



    function flipCard() {
        if (lockBoard)// אם  צריך לחסום את כל הקלפים
            return;

        this.classList.add("flip");

        if (this == firstCard) {// אם בחרנו שוב אותו קלף
            return;
        }

    //      // אם צריך לחסום את כל הקלפים או אם בחרנו שוב אותו קלף
    // if (lockBoard || this === firstCard) {
    //     return;
    // }

    // this.classList.add("flip");

        else if (!hasFlippedCard) {
            hasFlippedCard = true;
            firstCard = this;
            return;
        }

        else {//אם אני ברכטיס שני
            secondCard = this;
            lockBoard = true;
            checkMatch();
        }
    }

    function checkMatch() {
        //גישה לאטריביוטים שמתחילים במילה דאטה
        if (firstCard.dataset.framework == secondCard.dataset.framework)//אם יש התאמה אל תהפוך חזרה, ותעשה דיסאייבל כדי לא להפעיל ארוע לחיצה להבא
        {
            disableCards();
        }
        else
            flipBack();
    }

    function disableCards() {
        firstCard.removeEventListener("click", flipCard);
        secondCard.removeEventListener("click", flipCard);
        resetBoard();//אתחול המשתנים מחדש לזוג הבא
    }

    function flipBack() {
        setTimeout(() => {
            firstCard.classList.remove("flip");
            secondCard.classList.remove("flip");
            resetBoard();//אתחול המשתנים מחדש לזוג הבא
        }, 1500);// שניה וחצי
    }



    function resetBoard() {
        hasFlippedCard = false;
        firstCard = null;
        secondCard = null;
        lockBoard = false;
    }

});
